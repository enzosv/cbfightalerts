const web3 = require('./web3.js')
const utils = require('./utils.js')
const request = require('request');
const MINCHANCE = 0.93
const MINSTAMINA = 120
const MAXSTAMINA = 185
const TGBOTID = "226954229:AAFOV5kHe4cp8cDsDzKp_hn7xw5huDkqe9Y"
// 💧 ⚡️ 🔥 🌲
const MONITORS = [
    {
      "owner": "enzo",
      "chat_id": "16559538",
      "addresses": [
        {
          "address": "0x09F0576a1dE5F2f34a1c9C7C4c7E9751c4E0b697",
          "nickname": "💧"
        },
        {
          "address": "0x272f904Ab9DE155780ffe7614C5D4c752F75aeb7",
          "nickname": "🔥"
        },
        {
          "address": "0xBa2306a4e2AadF2C3A6084f88045EBed0E842bF9",
          "nickname": "⚡️"
        }
      ]
    },
    {
      "owner": "camille",
      "chat_id": "57959483",
      "addresses": [
        {
          "address": "0x2374b4cA100C920bbF79D1b765802257906b3067",
          "nickname": "⚡️"
        },
        {
            "address": "0xd18397F0F92b155874f7D8992ff48fF965CC4b11",
            "nickname": "🔥"
          }
      ]
    }
  ]

async function cron() {
    for(var i=0;i<MONITORS.length; i++){
        var messages = []
        var monitor = MONITORS[i]
        for(var j=0;j<monitor.addresses.length; j++){
            var address = monitor.addresses[j]
            await check(address.address, address.nickname, messages)
            messages.push("")
        }
        sendMessage(messages, monitor.chat_id)
    }
}

function sendMessage(messages, chat_id) {
    const data = {
        "chat_id": chat_id,
        "parse_mode":"markdown",
        "text":messages.join("\n")
    }
    request.post({
        url: 'https://api.telegram.org/bot'+TGBOTID+'/sendMessage',
        body: data,
        json: true
    }, function (error, response, body) {
        if (error){
          console.log(error.message)
        }
    });
}

async function check(address, nickname, messages) {
    const charIds = await web3.getAccountCharacters(address)
    const weapIds = await web3.getAccountWeapons(address)
    
    var characters = []
    for(var i=0; i<charIds.length; i++) {
        const charId = charIds[i]
        const sta = await web3.getCharacterStamina(charId)
        const charData = utils.characterFromContract(charId, await web3.getCharacterData(charId))
        charData.stamina = sta
        characters.push(charData)
    }

    //assumes an account only has 1 obviously strong weapon
    var strongest = {"strength":0}
    for(var i=0; i<weapIds.length; i++) {
        const weapId = weapIds[i]
        const weapData = utils.weaponFromContract(weapId, await web3.getWeaponData(weapId))
        weapData.strength = weapData.bonusPower+weapData.stat1Value+weapData.stat2Value+weapData.stat3Value
        if(weapData.strength > strongest.strength) {
            strongest = weapData
        }
    }
    for(var i=0; i<characters.length; i++) {
        var character = characters[i]
        if (character.stamina < MINSTAMINA) continue
        const targets = await web3.characterTargets(character.id, strongest.id)
        const enemies = await utils.getEnemyDetails(targets)
        var weakestEnemy = {"chance":MINCHANCE}
        for (var k=0; k<enemies.length; k++){
            const enemy = enemies[k]
            const chance = utils.getWinChance(character, strongest, enemy.power, enemy.trait)
            if (chance > weakestEnemy.chance || (character.stamina >= MAXSTAMINA && !weakestEnemy.index)) {
              enemy.chance = chance
              enemy.index = k
              weakestEnemy = enemy
            }
        }
        if(weakestEnemy.index > -1) {
          messages.push(
            nickname + " " + (i+1) 
            + " ("+ character.stamina + " sta):\n    *"
            + (weakestEnemy.chance*100).toFixed(2)
            + "%* vs " +(weakestEnemy.index+1) 
            + " (" + weakestEnemy.power + " " +utils.traitNumberToName(weakestEnemy.trait)+")"
          )
        }
    }
}

cron()